import unittest
import memory
import math
import exceptions.exceptions as the_exception

class TestMemoryFunctions(unittest.TestCase):
    pass

# Allows us to run the tests immediately when this file is run
if __name__ == '__main__':
    unittest.main()
